Ravioli Game Tools v2.10 Patch 1
2018-02-09

This patch fixes errors when opening some WAD files from League of Legends.

Errors occur with default-assets.wad and a few others.

The error message is "Unknown frame descriptor".

To install the patch, replace the original files in the installation directory with the files from this archive.
